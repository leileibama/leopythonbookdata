dict2 = {}

dict2['China'] = 'Chinese'
dict2['Britain'] = 'English'
dict2['Korea'] = 'Korean'
dict2['Germany'] = 'German'
dict2['Iran'] = 'Persian'

print(dict2)
# {'Germany': 'German', 'Britain': 'English', 'Korea': 'Korean', 'China': 'Chinese', 'Iran': 'Persian'}
