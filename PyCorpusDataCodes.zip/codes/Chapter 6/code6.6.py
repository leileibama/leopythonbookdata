dict1 = {'Mary':80, 'Tom':91, 'Jason':86, 'Julia':82}

for i in dict1.keys():
    print(i)                # 'Jason', 'Mary', 'Julia', 'Tom'

for i in dict1.values():
    print(i)                # 86, 80, 82, 91

for i in dict1.items():
    print(i)                # ('Jason', 86), ('Mary', 80), ('Julia', 82), ('Tom', 91)
