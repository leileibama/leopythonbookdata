dict1 = {'Mary':80, 'Tom':91, 'Jason':86, 'Julia':82}

dict2 = dict1.copy()
print(dict2)
# {'Jason': 86, 'Mary': 80, 'Julia': 82, 'Tom': 91}

# Same as the above
dict3 = dict1
print(dict3)
