dic = {'Math':80, 'Reading':90, 'Sports':88, 'Writing':90}

pairs =dic.items()  
# [('Reading', 90), ('Sports', 88), ('Writing', 90), ('Math', 80)]

pairs_reversed = []
for p in pairs:
    pairs_reversed.append([p[1], p[0]])
    # print(pairs_reversed)
# [[80, 'Math'], [90, 'Writing'], [88, 'Sports'], [90, 'Reading']]

pairs_reversed_sorted = sorted(pairs_reversed)
# [[80, 'Math'], [88, 'Sports'], [90, 'Reading'], [90, 'Writing']]
# sorted(pairs_reversed, reverse=True), if reversed order is needed.

for p in pairs_reversed_sorted:
    print(p[1], p[0])
