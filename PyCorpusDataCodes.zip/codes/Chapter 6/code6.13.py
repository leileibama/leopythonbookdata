import re

file_in = open("../texts/ge.txt", "r")
file_out = open("../ge_wordlist3.txt", "a")

all_words = []

for line in file_in.readlines():
    line2 = line.lower()
    line3 = re.sub(r'\W', r' ', line2)
    wordlist = line3.split()

    for word in wordlist:
        all_words.append(word)

wordlist_freq = {}

for word in all_words:
    if word in wordlist_freq.keys():
        wordlist_freq[word] += 1
    else:
        wordlist_freq[word] = 1

for k in sorted(wordlist_freq.keys()):
    file_out.write(k + '\t' + str(wordlist_freq[k]) + '\n')

file_in.close()
file_out.close()

#Note: This script runs much faster in Python 3.x than in Python 2.7