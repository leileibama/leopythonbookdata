dict1 = {'Mary':80, 'Tom':91}
dict2 = {'Jason':86, 'Julia':82}

dict2.update(dict1)
print(dict2)                      # {'Jason': 86, 'Mary': 80, 'Julia': 82, 'Tom': 91}

print(dict1)                      # {'Mary': 80, 'Tom': 91}
