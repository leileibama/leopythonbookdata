dict1 = {'Mary': 80, 'Tom': 91, 'Jason': 86, 'Julia': 82}

if 'Mary' in dict1.keys():
    print('Mary is one of the keys.')
else:
    print('Mary is not one of the keys.')

# Mary is one of the keys.
