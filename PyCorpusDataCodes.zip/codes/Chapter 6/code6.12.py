import re

string = '''<s n="2"><c type="pct">--</c> <w type="NN">Farm</w> <w type="NN">machinery</w> <w type="NN">dealer</w> <w type="NP">Bob</w> <w type="NP">Houtz</w> <w type="VBZ">tilts</w> <w type="RB">back</w> <w type="IN">in</w> <w type="AT">a</w> <w type="VBN">battered</w> <w type="NN">chair</w> <w type="CC">and</w> <w type="VBZ">tells</w> <w type="IN">of</w> <w type="AT">a</w> <w type="JJ">sharp</w> <w type="NN">pickup</w> <w type="IN">in</w> <w type="NNS">sales</w> <c type="pct">:</c> <c type="pct">``</c> <mw pos="PPSS HV">We've </mw><w type="VBN">sold</w> <w type="CD">four</w> <w type="NN">corn</w> <w type="NNS">pickers</w> <w type="IN">since</w> <w type="NN" subtype="TL">Labor</w> <w type="NN" subtype="TL">Day</w> <w type="CC">and</w> <w type="HV">have</w> <w type="JJ">good</w> <w type="NNS">prospects</w> <w type="IN">for</w> <w type="CD">10</w> <w type="AP">more</w> <c type="pct">.</c> </s>
<s n="3"><w type="PPSS">We</w> <w type="VBD">sold</w> <w type="RB">only</w> <w type="CD">four</w> <w type="NNS">pickers</w> <w type="ABN">all</w> <w type="AP">last</w> <w type="NN">year</w> <c type="pct">''</c> <c type="pct">.</c> </s>
'''
list1 = re.findall(r'<w type="(\w+)".*?>(\w+)', string)
# grouping the POS tag and the word
# [('NN', 'Farm'), ('NN', 'machinery'), ... , ('AP', 'last') , ('NN', 'year')]

dict1 = {}
for i in list1:
    noun, pos = reversed(i)   
    # reversed(i) looks like ('Farm', 'NN')
    # thus, noun is 'Farm', pos is 'NN'
    
    noun1 = noun.lower()   
    # noun1 is 'farm'

    dict1[noun1] = pos
    # {'Farm': 'NN'}

for k in dict1.keys():
    print(k, dict1[k])
