list1 = ['de Saussure', 'Chomsky', 'Sinclair']
list2 = ['Swiss', 'American', 'British']

dic = dict(zip(list1, list2))
print(dic)
# {'de Saussure': 'Swiss', 'Chomsky': 'American', 'Sinclair': 'British'}
