dic = {'Math': 80, 'Reading': 90, 'Sports': 88, 'Writing': 90}
dic_keys = dic.keys()
dic_keys_sorted = sorted(dic_keys)

for k in dic_keys_sorted:
    print(k, dic[k])
