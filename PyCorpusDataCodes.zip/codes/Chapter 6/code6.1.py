dict1 = {'Mary':80, 'Tom':91, 'Jason':86, 'Julia':82}

print(dict1['Mary'])     # 80
print(dict1['Jason'])    # 86
