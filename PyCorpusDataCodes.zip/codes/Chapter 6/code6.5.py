dict1 = {'Mary':80, 'Tom':91, 'Jason':86, 'Julia':82}
print(len(dict1))     # 4
