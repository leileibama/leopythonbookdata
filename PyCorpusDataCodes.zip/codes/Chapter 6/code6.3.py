dict2 = {'Germany': 'German', 'Britain': 'English', 'Korea': 'Korean', 'China': 'Chinese', 'Iran': 'Persian'}

dict2.pop('Korea')
print(dict2)
# {'China': 'Chinese', 'Britain': 'English', 'Germany': 'German', 'Iran': 'Persian'}

del(dict2['Germany'])
print(dict2)
# {'China': 'Chinese', 'Britain': 'English', 'Iran': 'Persian'}

dict2.clear()
print(dict2)    # {}，dict2 is an empty dictionary
