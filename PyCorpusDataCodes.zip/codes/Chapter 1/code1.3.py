# hello_world.py

# This is to assign "Hello world!" to the variable "string1"
string1 = "Hello world!"

# This will print out the variable on the screen
print(string1)
