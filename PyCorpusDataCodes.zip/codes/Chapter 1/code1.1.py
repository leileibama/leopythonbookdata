# hello_world.py
# This will print out "Hello world!" on the screen
print("Hello world!")
