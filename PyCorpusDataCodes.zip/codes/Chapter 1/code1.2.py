''' This is a multi-line
comment
of Python'''

'''
This is another multi-line
comment
of Python
'''
