str1 = '  Life is short     '
print(str1.strip())            # 'Life is short'
print(str1.lstrip())           # 'Life is short     '
print(str1.rstrip())           # '  Life is short'
