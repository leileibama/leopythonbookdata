import math

N = 1000000.0
f_x = 2844.0
f_y = 4393.0
f_xy = 335.0
MI = math.log((f_xy * N) / (f_x * f_y), 2)

print(MI)
