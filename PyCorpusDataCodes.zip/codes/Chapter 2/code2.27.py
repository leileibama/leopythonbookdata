x = 5             # Integer
print(str(x))     # Return a string: '5'

y = '6'           # String
print(float(y))   # Return a float: 6.0

print(y*x)        # Return a string: '66666'

print(float(y)*x) # Return a float: 30.0
print(int(y)*x)   # Return an integer: 30
