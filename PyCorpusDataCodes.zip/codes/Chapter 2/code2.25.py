name = 'David Smith'

print(name[0])        # 'D'
print(name[0:5])      # 'David'
print(name[6:9])      # 'Smi'
print(name[6:])       # 'Smith'
print(name[-1])       # 'h'
print(name[-3:-1])    # 'it'
