observed = float(1538)
corpus_size = float(2156586)

# Observed frequency per 1,000 words
relative1 = observed * 1000 / corpus_size
print(relative1)  # 0.713164232727

# Observed frequency per 1,000,000 words
relative2 = observed * 1000000 / corpus_size
print(relative2)  # 713.164232727
