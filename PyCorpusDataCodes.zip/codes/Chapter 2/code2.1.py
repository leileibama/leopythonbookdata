num1 = 8
print(num1)            # return: 8
print(type(num1))      # return: <type 'int'>

num2 = 8.0
print(num2)            # return: 8.0
print(type(num2))      # <type 'float'>
