num1 = 5                       # Integer
num2 = 2                       # Integer
num3 = 2.0                     # Float

print(num1 / num2)             # 2
print(num1 / num3)             # 2.5

print(38/189)                  # 0              (In Python 2.7)
                               # 0.201058201058 (In Python 3.x)
print(float(38/189))           # 0.0            (In Python 2.7)
                               # 0.201058201058 (In Python 3.x)
print(float(38)/float(189))    # 0.201058201058
