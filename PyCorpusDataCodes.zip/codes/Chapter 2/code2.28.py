str1 = 'Life is short'
str2 = 'we use python'

print(len(str1))            # 13

print(str1.lower())         # life is short
print(str2.upper())         # WE USE PYTHON

print(str2.capitalize())    # We use python
print(str2.title())         # We Use Python
print(str1.swapcase())      # lIFE IS SHORT
