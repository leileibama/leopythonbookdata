str1 = 'Life is short'
str2 = 'Year2013'

print(str1.startswith('L'))    # True. Note that Python is case-sensitive
print(str1.endswith('T'))      # False. Note that Python is case-sensitive
print(str1.isalnum())          # False. Note there's a space in the string
print(str2.isalnum())          # True
print(str2.isdigit())          # False

print(str1.islower())          # False
print(str1.isupper())          # False
print(str1.istitle())          # False

str3 = 'Life Is Short'
print(str3.istitle())          # True

str4 =  ''
str5 =  '  '
print(str4.isspace())          # False
print(str5.isspace())          # True
