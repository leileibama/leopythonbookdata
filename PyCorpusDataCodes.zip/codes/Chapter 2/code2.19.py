import math

N = 1000000.0
f_x = 2844.0
f_y = 4393.0
f_xy = 335.0

T = (f_xy - ( (f_x * f_y) / N) ) / math.sqrt(f_xy)
print(T)
