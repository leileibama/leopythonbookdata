import random

list1 = ['Mary', 'Michael', 'Julia', 'Leo']

print(random.sample(list1, 2))

print(list1)
