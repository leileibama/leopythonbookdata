print(abs(2.2))      # 2.2
print(abs(2.6))      # 2.6
print(abs(-2.6))     # 2.6
print(abs(0))        # 0
