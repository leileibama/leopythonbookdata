num1 = 5              # Integer
num2 = 2.0            # Float

print(num1)           # 5
print(num2)           # 2.0
print(float(num1))    # 5.0
print(int(num2))      # 2

print(int(2.2))       # 2
print(int(2.6))       # 2
