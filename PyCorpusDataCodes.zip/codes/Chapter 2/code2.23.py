print('''
Now let us praise the Guardian of the Kingdom of Heaven
the might of the Creator and the thought of his mind,
the work of the glorious Father, how He, the eternal Lord
established the beginning of every wonder.
For the sons of men, He, the Holy Creator
first made heaven as a roof, then the
Keeper of mankind, the eternal Lord
God Almighty afterwards made the middle world
the earth, for men.
--(Caedmon, Hymn, St Petersburg Bede)
''')
