import math

print(math.sqrt(9))     # 3.0
print(math.sqrt(26))    # 5.09901951359
