num1 = 5
num2 = 2

print(num1 + num2)    # 7
print(num1 - num2)    # 3
print(num1 * num2)    # 10
print(num1 / num2)    # 2   (In Python 2.7)
                      # 2.5 (In Python 3.x)
print(num1 ** num2)   # 25
print(num1 // num2)   # 2
print(num1 % num2)    # 1
