import math

entropy = -( 4 * (1.0 / 8) * math.log((1.0 / 8), 2) + 2 * (1.0 / 4) * math.log(float(1.0 / 4), 2) )

print(entropy)
