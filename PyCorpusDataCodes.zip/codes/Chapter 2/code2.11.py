import math

print(math.log(1008, 2))     # 9.9772799235
print(math.log(1008, 10))    # 3.00346053211
