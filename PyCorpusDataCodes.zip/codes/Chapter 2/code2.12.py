import math

print(math.log(1008))    # 6.91572344863
