pi = 3.1415
r = 26.5
S = pi * r * r
print(S)  # 2206.118375
