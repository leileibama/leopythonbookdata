from math import e, log

print(log(1008, e))  # 6.91572344863
