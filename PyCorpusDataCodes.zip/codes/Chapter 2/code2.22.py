first_name = 'David'
last_name = "Smith"

print(first_name)    # 'David'
print(last_name)     # 'Smith'
