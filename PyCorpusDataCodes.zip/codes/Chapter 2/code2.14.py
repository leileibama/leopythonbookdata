import random

print(random.random())

print(random.randint(0, 10))

print(random.randrange(1, 10))
print(random.randrange(1, 10, 2))
