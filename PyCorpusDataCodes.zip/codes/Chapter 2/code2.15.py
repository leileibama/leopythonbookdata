import random

list1 = ['Mary', 'Michael', 'Julia', 'Leo']

print(random.choice(list1))

random.shuffle(list1)
print(list1)
