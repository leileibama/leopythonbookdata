first_name = 'David'
last_name = 'Smith'

name1 = first_name + last_name
print(name1)                            # 'DavidSmith'

name2 = first_name + ' ' + last_name    # There is a space in between ' '
print(name2)                            # 'David Smith'

print(first_name * 2)                   # 'DavidDavid'

print((first_name + ' ') * 2)           # 'David David'
