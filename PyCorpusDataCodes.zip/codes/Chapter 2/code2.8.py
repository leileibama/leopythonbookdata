print(round(5.4))          # 5 (In Python 3.x)
print(round(5.5))          # 6 (In Python 3.x)
print(round(5.6))          # 6 (In Python 3.x)

print(type(round(5.6)))    # <class 'int'> (In Python 3.x)
