print(round(5.4356, 3))          # 5.436
print(round(-85.4346, 2))        # -85.43

print(type(round(-85.4346, 2)))  # <class 'float'> (In Python 3.x)
                                 # <type 'float'>  (In Python 2.7)
