string1 = 'This is the slogan: "Life is short, we use Python!"'
print(string1)
# This is the slogan: "Life is short, we use Python!"

string2 = "This is the slogan: 'Life is short, we use Python!'"
print(string2)
# This is the slogan: 'Life is short, we use Python!'

string3 = "This is the slogan: \"Life is short, we use Python!\""
print(string3)
# This is the slogan: "Life is short, we use Python!"

string4 = "This is the backslash\"
print(string4)
'''
SyntaxError: EOL while scanning string literal
'''

string5 = "This is the backslash\""
print(string5)    # This is the backslash"

string6 = "This is the backslash\\"
print(string6)    # This is the backslash\

string7 = r"This is the slogan: \"Life is short, we use Python!\""
print(string7)    # This is the slogan: \"Life is short, we use Python!\"

string8 = r"This is the backslash\\"
print(string8)    # This is the backslash\\
