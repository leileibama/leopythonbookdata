print(round(5.4))          # 5.0 (In Python 2.7)
print(round(5.5))          # 6.0 (In Python 2.7)
print(round(5.6))          # 6.0 (In Python 2.7)

print(type(round(5.6)))    # <type 'float'> (In Python 2.7)
