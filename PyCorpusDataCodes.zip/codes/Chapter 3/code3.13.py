numbers = range(1,11)
file_out = open("../numbers.txt", "a")

for i in numbers:
    out = str(i) + '\n'
    file_out.write(out)

file_out.close()
