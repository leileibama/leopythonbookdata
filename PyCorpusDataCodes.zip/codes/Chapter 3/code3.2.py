str1 = 'Life is short, we use Python.'

if len(str1) > 30:
    print('The string has more than 30 characters.')
else:
    print('The string has less than 30 characters.')  # Print this sentence

str2 = 'Python'
if str2.startswith('p'):
    print('Yeah!')
else:
    print('Oh, no!')                                  # Print this sentence
