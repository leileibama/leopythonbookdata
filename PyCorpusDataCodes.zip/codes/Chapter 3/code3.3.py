str1 = 'Python_N'

if str1.endswith('V'):
    print('This is a verb.')          # Pass
elif str1.endswith('N'):
    print('This is a noun.')          # Print 'This is a noun.'
elif str1.endswith('A'):
    print('This is an adjective.')    # Pass
elif str1.endswith('R'):
    print('This is an adverb.')       # Pass
else:
    print('This is a function word')  # Pass
