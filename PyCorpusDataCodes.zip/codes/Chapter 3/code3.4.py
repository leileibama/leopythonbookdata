print("Please type in the p value: ")
p = float(input())

if p >= .05:
       print("Not significant!")
else:
       print("Significant!")
