file_in = open("../texts/ge.txt", "r")

for line in file_in:
    print(line)

file_in.close()
