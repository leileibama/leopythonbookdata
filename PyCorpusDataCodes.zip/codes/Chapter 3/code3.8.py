word = 'Python'

for letter in word:
    print(letter.upper())
