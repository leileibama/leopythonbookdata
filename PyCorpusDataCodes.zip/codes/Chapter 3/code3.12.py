file_in = open("../texts/ge.txt", "r")
file_out = open("../ge_lower.txt", "a") # Change '../ge_lower.txt' to your desired path

for line in file_in.readlines():
    line_new = line.lower()
    file_out.write(line_new)

file_in.close()
file_out.close()
