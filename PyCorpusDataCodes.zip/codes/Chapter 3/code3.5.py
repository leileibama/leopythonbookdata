import random

# Generate a random number in between 0-8
number1 = random.randint(0, 8)

print("Please type in an integer x: 0 <= x < 9.\n")

# Assign user input to 'number2'
number2 = int(input())

if number1 == number2:
    print("Good job!\n")

elif number1 > number2:
    print("The random number is bigger than yours!\n")

else:
    print("The random number is smaller than yours!\n")

print("The random number is " + str(number1) + '.')
