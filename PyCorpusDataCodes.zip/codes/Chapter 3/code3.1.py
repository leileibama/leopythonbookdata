str1 =  'Life is short, we use Python.'

if len(str1) > 10:
    print('The string has more than 10 characters.')   # Print the sentence

str2 = 'Python'
if str2.startswith('p'):
    print(str2)                                        # Python is case-sensitive
