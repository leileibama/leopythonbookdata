prefix = "A"
start = 2011001
end = 2011101

for i in range(start, end):
    print(prefix + str(i))
