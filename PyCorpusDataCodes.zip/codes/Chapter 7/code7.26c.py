	# Dependencies_collocations.py  Part 3

    # to extract all contents
    # between <dep type="amod"> and </dep>
    amod = re.findall(r'<dep type="amod">.*?</dep>', i, re.DOTALL)

    for j in amod:
        file_out.write('amod' + '\t')
        dep = re.search(r'<dependent.*?/dependent>', j).group() # dependent
        dep_word = re.sub(r'<.*?>', r'', dep).strip()
        file_out.write(dep_word + '\t')

        gov = re.search(r'<governor.*?/governor>', j).group() # governor
        gov_word = re.sub(r'<.*?>', r'', gov).strip()
        file_out.write(gov_word + '\n')

    # to extract all contents
    # between <dep type="nn"> and </dep>
    nn = re.findall(r'<dep type="nn">.*?</dep>', i, re.DOTALL)

    for j in nn:
        file_out.write('nn' + '\t')
        dep = re.search(r'<dependent.*?/dependent>', j).group() # dependent
        dep_word = re.sub(r'<.*?>', r'', dep).strip()
        file_out.write(dep_word + '\t')

        gov = re.search(r'<governor.*?/governor>', j).group() # governor
        gov_word = re.sub(r'<.*?>', r'', gov).strip()
        file_out.write(gov_word + '\n')

    # to extract all contents
    # between <dep type="advmod"> and </dep>
    advmod = re.findall(r'<dep type="advmod">.*?</dep>', i, re.DOTALL)

    for j in advmod:
        file_out.write('advmod' + '\t')
        dep = re.search(r'<dependent.*?/dependent>', j).group() # dependent
        dep_word = re.sub(r'<.*?>', r'', dep).strip()
        file_out.write(dep_word + '\t')

        gov = re.search(r'<governor.*?/governor>', j).group() # governor
        gov_word = re.sub(r'<.*?>', r'', gov).strip()
        file_out.write(gov_word + '\n')

file_in.close()
file_out.close()
