# Dependencies_collocations.py  Part 1

import re

file_in = open("../texts/un_history.txt.xml", "r")
file_out = open("../un_history_collocations.txt", "a")

# to extract all contents between
# <dependencies type="basic-dependencies">
# and </dependencies>
basic_dep = re.findall(r'<dependencies type="basic-dependencies">.*?</dependencies>', file_in.read(), re.DOTALL)

# Dependencies_collocations.py  Part 2

for i in basic_dep:
    # Extract all contents between <dep type="dobj"> and </dep>
    dobj = re.findall(r'<dep type="dobj">.*?</dep>', i, re.DOTALL)

    for j in dobj:
        file_out.write('dobj' + '\t')
        dep = re.search(r'<dependent.*?/dependent>', j).group()      # Dependent
        dep_word = re.sub(r'<.*?>', r'', dep).strip()
        file_out.write(dep_word + '\t')

        gov = re.search(r'<governor.*?/governor>', j).group()        # Governor
        gov_word = re.sub(r'<.*?>', r'', gov).strip()
        file_out.write(gov_word + '\n')
	
	# Dependencies_collocations.py  Part 3

    # to extract all contents
    # between <dep type="amod"> and </dep>
    amod = re.findall(r'<dep type="amod">.*?</dep>', i, re.DOTALL)

    for j in amod:
        file_out.write('amod' + '\t')
        dep = re.search(r'<dependent.*?/dependent>', j).group() # dependent
        dep_word = re.sub(r'<.*?>', r'', dep).strip()
        file_out.write(dep_word + '\t')

        gov = re.search(r'<governor.*?/governor>', j).group() # governor
        gov_word = re.sub(r'<.*?>', r'', gov).strip()
        file_out.write(gov_word + '\n')

    # to extract all contents
    # between <dep type="nn"> and </dep>
    nn = re.findall(r'<dep type="nn">.*?</dep>', i, re.DOTALL)

    for j in nn:
        file_out.write('nn' + '\t')
        dep = re.search(r'<dependent.*?/dependent>', j).group() # dependent
        dep_word = re.sub(r'<.*?>', r'', dep).strip()
        file_out.write(dep_word + '\t')

        gov = re.search(r'<governor.*?/governor>', j).group() # governor
        gov_word = re.sub(r'<.*?>', r'', gov).strip()
        file_out.write(gov_word + '\n')

    # to extract all contents
    # between <dep type="advmod"> and </dep>
    advmod = re.findall(r'<dep type="advmod">.*?</dep>', i, re.DOTALL)

    for j in advmod:
        file_out.write('advmod' + '\t')
        dep = re.search(r'<dependent.*?/dependent>', j).group() # dependent
        dep_word = re.sub(r'<.*?>', r'', dep).strip()
        file_out.write(dep_word + '\t')

        gov = re.search(r'<governor.*?/governor>', j).group() # governor
        gov_word = re.sub(r'<.*?>', r'', gov).strip()
        file_out.write(gov_word + '\n')

file_in.close()
file_out.close()
