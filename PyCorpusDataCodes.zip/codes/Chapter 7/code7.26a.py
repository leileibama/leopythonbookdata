# Dependencies_collocations.py  Part 1

import re

file_in = open("../texts/un_history.txt.xml", "r")
file_out = open("../un_history_collocations.txt", "a")

# to extract all contents between
# <dependencies type="basic-dependencies">
# and </dependencies>
basic_dep = re.findall(r'<dependencies type="basic-dependencies">.*?</dependencies>', file_in.read(), re.DOTALL)
