import re

file_in = open("../texts/ge.txt", "r")
file_out = open("../ge_tional.txt", "a")

for line in file_in.readlines():
    if re.search(r'\w+tional\b', line):
        file_out.write(line + '\n')

file_in.close()
file_out.close()
