# Recognizing_gsl_awl_words.py, Part 3-1

# The following code is to categorize the words in wordlist_freq_dict
# into dictionaries of GSL1000 words, GSL2000 words, AWL words or others

gsl1000_words = {}
gsl2000_words = {}
awl_words = {}
other_words = {}

for word in wordlist_freq_dict.keys():
    if word not in gsl_awl_dict.keys():
        other_words[word] = 4
    elif gsl_awl_dict[word] == 1:
        gsl1000_words[word] = wordlist_freq_dict[word]
    elif gsl_awl_dict[word] == 2:
        gsl2000_words[word] = wordlist_freq_dict[word]
    elif gsl_awl_dict[word] == 3:
        awl_words[word] = wordlist_freq_dict[word]
