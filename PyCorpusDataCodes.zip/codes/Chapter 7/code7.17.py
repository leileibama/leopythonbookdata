import os

target_dir = '../texts/'

files = os.listdir(target_dir)

for file in files:
    if file.endswith(r".txt"):
        print(file)
