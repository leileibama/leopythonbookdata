import re
import nltk
from nltk.util import ngrams

string = "My father's family name being Pirrip, and my Christian name Philip, my infant tongue could make of both names nothing longer or more explicit than Pip. So, I called myself Pip, and came to be called Pip."

string_tokenized = nltk.word_tokenize(string.lower())
n = 4
n_grams = ngrams(string_tokenized, n)

n_grams_AlphaNum = []

for gram in n_grams:
    # To test if there is any non-alphanumeric character in the ngrams
    if re.search(r'^\W+$', gram[0]) or re.search(r'^\W+$', gram[1]) or re.search(r'^\W+$', gram[2]) or re.search(r'^\W+$', gram[3]):
        continue  # If there is, do nothing
    else:
        n_grams_AlphaNum.append(gram)

for i in n_grams_AlphaNum:
    print(i)
