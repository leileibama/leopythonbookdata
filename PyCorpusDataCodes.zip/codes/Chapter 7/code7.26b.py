# Dependencies_collocations.py  Part 2

for i in basic_dep:
    # Extract all contents between <dep type="dobj"> and </dep>
    dobj = re.findall(r'<dep type="dobj">.*?</dep>', i, re.DOTALL)

    for j in dobj:
        file_out.write('dobj' + '\t')
        dep = re.search(r'<dependent.*?/dependent>', j).group()      # Dependent
        dep_word = re.sub(r'<.*?>', r'', dep).strip()
        file_out.write(dep_word + '\t')

        gov = re.search(r'<governor.*?/governor>', j).group()        # Governor
        gov_word = re.sub(r'<.*?>', r'', gov).strip()
        file_out.write(gov_word + '\n')
