for root, subFolders, files in os.walk(rootdir):
    #print("root: ", root)
    #print("subFolders: ", subFolders)
    #print("files: ", files, '\n')
