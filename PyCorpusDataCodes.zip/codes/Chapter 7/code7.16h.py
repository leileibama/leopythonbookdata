# Recognizing_gsl_awl_words.py, Part 4-3

# write out the GSL1000 words
file_out.write('\n\n')
file_out.write('##########\n')
file_out.write('Words in GSL1000\n\n')
for word in sorted(gsl1000_words.keys()):
    file_out.write(word + '\t' + str(gsl1000_words[word]) + '\n')

# write out the GSL2000 words
file_out.write('\n\n')
file_out.write('##########\n')
file_out.write('Words in GSL2000\n\n')
for word in sorted(gsl2000_words.keys()):
    file_out.write(word + '\t' + str(gsl2000_words[word]) + '\n')

# write out the AWL words
file_out.write('\n\n')
file_out.write('##########\n')
file_out.write('Words in AWL\n\n')
for word in sorted(awl_words.keys()):
    file_out.write(word + '\t' + str(awl_words[word]) + '\n')

# write out other words
file_out.write('\n\n')
file_out.write('##########\n')
file_out.write('Other words\n\n')
for word in sorted(other_words.keys()):
    file_out.write(word + '\t' + str(wordlist_freq_dict[word]) + '\n')

file_out.close()
