# Recognizing_gsl_awl_words.py, Part 1

# The following code is to make the wordlist with freq
# and store the info in a dictionary (wordlist_freq_dict)

import re

file_in = open("../texts/ge.txt", "r")
all_words = []

for line in file_in.readlines():
    line2 = line.lower()
    line3 = re.sub(r'\W', r' ', line2)
    wordlist = line3.split()
    
    for word in wordlist:
        all_words.append(word)

wordlist_freq_dict = {}
for word in all_words:
    if word in wordlist_freq_dict.keys():
        wordlist_freq_dict[word] += 1
    else:
        wordlist_freq_dict[word] = 1

file_in.close()
