import nltk

file_in = open("../texts/ge.txt", "r")
file_out = open("../ge_wordlist4.txt", "a")

# Tokenize the input text into sentences
# Save output in 'all_sentences'
all_sentences = []
sent_tokenizer = nltk.data.load('tokenizers/punkt/english.pickle')

for line in file_in.readlines():
    sents = sent_tokenizer.tokenize(line)
    
    for sent in sents:
        all_sentences.append(sent)

# Tokenize sentences into words
# Save output in 'all_words'
all_words = []
for sent in all_sentences:
    sent_tokenized = nltk.word_tokenize(sent)
    
    for word in sent_tokenized:
        all_words.append(word.lower())

# Count word frequency
# Save output in 'wordlist_freq'
wordlist_freq = {}
for word in all_words:
    if word in wordlist_freq.keys():
        wordlist_freq[word] += 1
    else:
        wordlist_freq[word] = 1

# Sort word frequency in reverse order 
# Save output in 'pairs_reversed'
pairs_reversed = []
for p in wordlist_freq.items():
    pairs_reversed.append([p[1], p[0]])

pairs_reversed_sorted = sorted(pairs_reversed, reverse = True)

# Write word frequency in 'file_out'
for p in pairs_reversed_sorted:
    file_out.write(p[1] + '\t' + str(p[0]) + '\n')

file_in.close()
file_out.close()
