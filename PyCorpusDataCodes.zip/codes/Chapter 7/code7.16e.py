# Recognizing_gsl_awl_words.py, Part 3-3

# to compute the number of words in gsl1000, gsl2000, awl and other words
gsl1000_num_of_words = len(gsl1000_words)
gsl2000_num_of_words = len(gsl2000_words)
awl_num_of_words = len(awl_words)
other_num_of_words = len(other_words)

freq_total = gsl1000_freq_total + gsl2000_freq_total + awl_freq_total + other_freq_total
num_of_words_total = gsl1000_num_of_words + gsl2000_num_of_words + awl_num_of_words + other_num_of_words
