import os

target_dir = '../texts/'

files = os.listdir(target_dir)

file_out = open(target_dir + 'files_combined.txt', 'a')
#file_out = open(target_dir + 'files_combined.txt', 'a', encoding = 'utf-8')      #For Python 3.x

for file in files:
    if file.endswith(r".txt"):
        file_in = open(target_dir + file, 'r')
		#file_in = open(target_dir + file, 'r', encoding = 'utf-8')               #For Python 3.x
        text = file_in.readlines()

        for t in text:
            file_out.write(t)
        file_in.close()

file_out.close()
