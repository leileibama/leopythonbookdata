import os

rootdir = '../texts/'
allfiles = []

for root, subFolders, files in os.walk(rootdir):
    for file in files:
        allfiles.append(os.path.join(root, file))

for i in allfiles:
    if i.endswith('.txt'):
        print(i)
