# To compute the frequency of ngrams in n_grams_AlphaNum
# Put this snippet of code after the second snippet of code in Section 7.4 
freq_dict = {}

for i in n_grams_AlphaNum:
    if i in freq_dict.keys():
        freq_dict[i] +=1
    else:
        freq_dict[i] = 1

for j in freq_dict.keys():
    if freq_dict[j] >=2:
        print(j[0], j[1], j[2], j[3], '\t', freq_dict[j])
