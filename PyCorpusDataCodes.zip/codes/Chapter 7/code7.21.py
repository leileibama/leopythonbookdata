import os

allfiles = []

rootdir = '../texts/'
file_out = open(rootdir + 'allfiles_combined.txt', 'a')
#file_out = open(rootdir + 'allfiles_combined.txt', 'a', encoding = 'utf-8')      #For Python 3.x

for root, subFolders, files in os.walk(rootdir):
    for file in files:
        allfiles.append(os.path.join(root, file))

for i in allfiles:
     if i.endswith('.txt'):
        file_in = open(i, 'r')
        #file_in = open(i, 'r', encoding = 'utf-8')                               #For Python 3.x

        for line in file_in.readlines():
             file_out.write(line)
        file_in.close()

file_out.close()
