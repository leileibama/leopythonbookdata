# Recognizing_gsl_awl_words.py, Part 4-1

# The following code is to write out the results
# first, define the file to save the results
file_out = open("../range_wordlist_results.txt", "a")

# then, write out the results
file_out.write('RESULTS OF WORD ANALYSIS\n\n')
file_out.write('Total No. of word types in Great Expectations: ' + str(num_of_words_total) + '\n\n')
file_out.write('No. of GSL1000 word types: ' + str(gsl1000_num_of_words) + '\n')
file_out.write('No. of GSL2000 word types: ' + str(gsl2000_num_of_words) + '\n')
file_out.write('No. of AWL word types: ' + str(awl_num_of_words) + '\n')
file_out.write('No. of other word types: ' + str(other_num_of_words) + '\n')
