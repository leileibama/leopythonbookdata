import nltk

string = "My father's family name being Pirrip, and my Christian name Philip, my infant tongue could make of both names nothing longer or more explicit than Pip. So, I called myself Pip, and came to be called Pip."

# Tokenize the string
sent_splitter = nltk.data.load('tokenizers/punkt/english.pickle')
sents_splitted = sent_splitter.tokenize(string)

file_out = open("../sent_postagged.txt", "a")

# Postag the tokenized sentence
for sent in sents_splitted:
      # Postag the sentence
      sent_tokenized = nltk.word_tokenize(sent)
      sent_postag = nltk.pos_tag(sent_tokenized)

      # Save the postagged sentence in sent_postagged
      for i in sent_postag:
             output = i[0] + '_' + i[1] + ' '
             file_out.write(output)
      file_out.write('\n')

file_out.close()
