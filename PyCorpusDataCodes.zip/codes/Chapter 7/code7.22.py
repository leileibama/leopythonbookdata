import os

target_dir = '../texts/temp_folder/'

files = os.listdir(target_dir)

for file in files:
    if file.endswith(".txt"):
        # Open the txt file
        file_in = open(target_dir + file, 'r')
        text = file_in.readlines()

        # Open the new txt file with file name changed
        file_out = open(target_dir + file[:-4] + "_changed.txt", "a")

        for t in text:
            file_out.write(t)

        file_in.close()
        file_out.close()
