# Recognizing_gsl_awl_words.py, Part 3-2

# compute freq total
gsl1000_freq_total = 0
gsl2000_freq_total = 0
awl_freq_total = 0
other_freq_total = 0
for word in gsl1000_words:
    gsl1000_freq_total += wordlist_freq_dict[word]
for word in gsl2000_words:
    gsl2000_freq_total += wordlist_freq_dict[word]
for word in awl_words:
    awl_freq_total += wordlist_freq_dict[word]
for word in other_words:
    other_freq_total += wordlist_freq_dict[word]
