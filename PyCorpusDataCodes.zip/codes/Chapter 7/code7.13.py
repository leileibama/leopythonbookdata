import nltk

file_in = open('../texts/ge.txt', 'r')
raw_text = file_in.read()
tokens = nltk.word_tokenize(raw_text)

nltk_text = nltk.Text(tokens)

nltk_text.concordance('but')
