import nltk
from nltk.util import ngrams

string = "My father's family name being Pirrip, and my Christian name Philip, my infant tongue could make of both names nothing longer or more explicit than Pip. So, I called myself Pip, and came to be called Pip."

string_tokenized = nltk.word_tokenize(string.lower())

n = 4

n_grams = ngrams(string_tokenized, n)

for grams in n_grams:
    print(grams)
