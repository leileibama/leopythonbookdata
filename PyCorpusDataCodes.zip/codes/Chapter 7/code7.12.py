import nltk
from nltk.corpus import stopwords

stopwords_list = stopwords.words('english')
print(stopwords_list)

string = "My father's family name being Pirrip, and my Christian name Philip, my infant tongue could make of both names nothing longer or more explicit than Pip. So, I called myself Pip, and came to be called Pip."

wordlist = nltk.word_tokenize(string.lower())

for word in wordlist:
   if word not in stopwords_list:
      print(word)
