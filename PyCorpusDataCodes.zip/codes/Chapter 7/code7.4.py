import nltk

string = "My father's family name being Pirrip, and my Christian name Philip, my infant tongue could make of both names nothing longer or more explicit than Pip. So, I called myself Pip, and came to be called Pip."

string_tokenized = nltk.word_tokenize(string)

string_postagged = nltk.pos_tag(string_tokenized)
print(string_postagged)

for i in string_postagged:
    print(i[0] + '_' + i[1])
