import re

file_in = open("../texts/un_history.txt.xml", "r")
file_out = open("../un_history_lemma_pos.txt", "a")

for line in file_in.readlines():
    line2 = line.strip()                               #  strip the spaces, including the newline character in the line

    if line2.startswith("<word>"):  
        word = re.sub(r'<.*?>', '', line).strip()      # replace '<.*?>' with nothing
        file_out.write(word + '\t')                    # write out the word
    elif line2.startswith("<lemma>"):
        lemma = re.sub(r'<.*?>', '', line2).strip()
        file_out.write(lemma + '\t')
    elif line2.startswith("<POS>"):
        pos = re.sub(r'<.*?>', '', line2).strip()
        file_out.write(pos + '\n')

file_in.close()
file_out.close()
