import nltk

from nltk.stem.wordnet import WordNetLemmatizer

lemmatizer = WordNetLemmatizer()

print(lemmatizer.lemmatize('books', 'n'))       # book

print(lemmatizer.lemmatize('went', 'v'))        # go

print(lemmatizer.lemmatize('better', 'a'))      # good

print(lemmatizer.lemmatize('geese'))            # goose
