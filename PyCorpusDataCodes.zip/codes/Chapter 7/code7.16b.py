# Recognizing_gsl_awl_words.py, Part 2

# The following code is to read the GSL and the AWL words
# and save them in a dictionary
gsl1000_in = open("../texts/GSL1000.txt", "r")
gsl2000_in = open("../texts/GSL2000.txt", "r")
awl_in = open("../texts/AWL.txt", "r")

gsl_awl_dict = {}
for word in gsl1000_in.readlines():
    gsl_awl_dict[word.strip()] = 1
for word in gsl2000_in.readlines():
    gsl_awl_dict[word.strip()] = 2
for word in awl_in.readlines():
    gsl_awl_dict[word.strip()] = 3

gsl1000_in.close()
gsl2000_in.close()

awl_in.close()
