# -*- encoding: utf8 -*-

import jieba

seg_list = jieba.cut("联合国是1945年第二次世界大战后成立的国际组织。")
print(" ".join(seg_list))
