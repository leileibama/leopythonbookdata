# -*- encoding: utf8 -*-

import re
import codecs

file_in = codecs.open('../texts/cn_sample_segmented.txt', 'r', encoding = 'utf-8')

for line in file_in.readlines():
    if re.search(r'\b提高\b', line):
        print(line)

file_in.close()
