# -*- encoding: utf8 -*-
import codecs

dir = '../texts/'
bitext_en_in = codecs.open(dir + 'bitext_en.txt', 'r', encoding = 'utf-8')
bitext_cn_in = codecs.open(dir + 'bitext_cn.txt', 'r', encoding = 'utf-8')
bitext_out = codecs.open(dir + 'bitext2.txt', 'a', encoding = 'utf-8')

bitext_en_temp = []
bitext_cn_temp = []

for line in bitext_en_in.readlines():
    bitext_en_temp.append(line)

for line in bitext_cn_in.readlines():
    bitext_cn_temp.append(line)

bitext_dict = dict(zip(bitext_en_temp, bitext_cn_temp))

for i in bitext_dict.keys():
    bitext_out.write(i)
    bitext_out.write(bitext_dict[i])

bitext_en_in.close()
bitext_cn_in.close()
bitext_out.close()
