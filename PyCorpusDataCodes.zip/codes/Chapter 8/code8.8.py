# -*- encoding: utf8 -*-
import codecs

dir = '../texts/'

bitext_in = codecs.open(dir + 'bitext.txt', 'r', encoding = 'utf-8')
bitext_en_out = codecs.open(dir + 'bitext_en.txt', 'a', encoding = 'utf-8')
bitext_cn_out = codecs.open(dir + 'bitext_cn.txt', 'a', encoding = 'utf-8')

bitext_temp = []

for line in bitext_in.readlines():
    bitext_temp.append(line)

for i in range(len(bitext_temp)):
    if i % 2 == 0:
        bitext_en_out.write(bitext_temp[i])
    elif i % 2 == 1:
        bitext_cn_out.write(bitext_temp[i])

bitext_in.close()
bitext_en_out.close()
bitext_cn_out.close()
