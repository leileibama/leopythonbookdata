# -*- encoding: utf8 -*-

import codecs
import jieba

file_in = codecs.open("../texts/cn_sample.txt", 'r', encoding = 'utf-8')
file_out = codecs.open("../cn_sample_segmented2.txt", 'a', encoding = 'utf-8')

for line in file_in.readlines():
    seg_list = jieba.cut(line)
    file_out.write(" ".join(seg_list))

file_in.close()
file_out.close()
