./segment.sh ctb cn_sample.txt UTF-8 0 > cn_sample_segmented.txt

./segment.sh pku cn_sample.txt UTF-8 0 > cn_sample_segmented.txt
