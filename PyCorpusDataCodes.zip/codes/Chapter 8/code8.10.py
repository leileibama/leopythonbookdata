for i in bitext_en_temp:
    bitext_out.write(i)
    bitext_out.write(bitext_dict[i])
