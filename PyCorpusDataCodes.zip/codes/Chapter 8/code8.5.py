# -*- encoding: utf8 -*-

import jieba
import jieba.posseg as pseg

words = pseg.cut("联合国是1945年第二次世界大战后成立的国际组织。")

for w in words:
    print(w.word + "_" + w.flag)
    # out = w.word + "_" + w.flag
    # print(out.encode("UTF-8"))
