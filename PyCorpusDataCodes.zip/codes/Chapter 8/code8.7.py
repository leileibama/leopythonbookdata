# -*- encoding: utf8 -*-
import re
import codecs

file_in = codecs.open('../texts/cn_sample_segmented_tagged.txt', 'r', encoding = 'utf-8')

nouns = []
for line in file_in.readlines():
       for noun in re.findall(r'\w+\#N\w+', line):
             nouns.append(noun)
print(nouns)
file_in.close()
