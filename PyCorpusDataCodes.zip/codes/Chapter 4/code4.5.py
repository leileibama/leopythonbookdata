string = "Python"
print(list(string))
