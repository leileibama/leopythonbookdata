list4 = ['a', 'BBB', 'Aa', 'ba', 'A', 'b', 'CC']

print(sorted(list4, key = len))    # ['a', 'A', 'b', 'Aa', 'ba', 'CC', 'BBB']
