tup3 = ('Mary', 'Tom', 'Julia', 'Michael')
list1 = list(tup3)
print(list1)
print(tuple(list1))
