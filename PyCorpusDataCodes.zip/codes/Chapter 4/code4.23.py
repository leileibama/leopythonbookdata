tup2 = ('c', 'b', 'a')
print(tup2[0], tup2[-1])
