list4 = ['a', 'BB', 'Aa', 'ba', 'c', 'A', 'Cb', 'b', 'CC']

print(sorted(list4))    # ['A', 'Aa', 'BB', 'CC', 'Cb', 'a', 'b', 'ba', 'c']
