# add_line_number.py
# this is to add a line number to each line of a text

file_in = open("../texts/poem.txt", "r")
file_out = open("../poem2.txt", "a")

list0 = []

for line in file_in.readlines():
    list0.append(line)

list0_max = len(list0)

i = 0

for line in list0:
    if i < list0_max:
        line_out = str(i + 1) + '\t' + line
        file_out.write(line_out)
        i = i + 1

file_in.close()
file_out.close()
