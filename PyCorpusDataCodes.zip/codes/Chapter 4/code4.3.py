str1 = '  Life is'
print(str1.split())       # ['Life', 'is']

str2 = '2013-10-06'
print(str2.split('-'))    # ['2013', '10', '06']
