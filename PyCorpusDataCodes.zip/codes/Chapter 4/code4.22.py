tup1 = (1, 2, 3)

for i in tup1:
    print(i)
