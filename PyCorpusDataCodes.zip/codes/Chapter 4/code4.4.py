list1 = ['Life', 'is', 'short']

print(''.join(list1))           # Lifeisshort
print(' '.join(list1))          # Life is short
print('--'.join(list1))         # Lif--is--short
