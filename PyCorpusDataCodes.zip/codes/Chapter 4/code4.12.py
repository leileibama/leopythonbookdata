list3 = [12, 1, 8, 5]

print(sorted(list3))       # [1, 5, 8, 12]
