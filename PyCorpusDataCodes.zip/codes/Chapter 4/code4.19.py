# wordlist1.py

file_in = open("../texts/ge.txt", "r")
file_out = open("../ge_wordlist.txt", "a")

list0 = []                             # an empty list to store all words 

for line in file_in.readlines():       # read in all lines of the text
    line_new = line.lower()            # change line into lower case
    list1 = line_new.split()           # split the line into words by space
    
    for word in list1:
        list0.append(word)             # append the words into list0

list2 = list(set(list0))               # delete repetitions of list0

list3 = sorted(list2, key = str.lower) # alphabeticall sort list2

for word in list3:
    file_out.write(word + '\n')        # write out the words

file_in.close()
file_out.close()
