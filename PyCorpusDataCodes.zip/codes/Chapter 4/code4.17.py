list3 = ['a', 'c', 'b', 'b', 'a']
print(list3.count('a'))
