list3 = ['a', 'c', 'b', 'b', 'a']
print(set(list3))
print(list(set(list3)))
