list4 = ['a', 'c', 'b', 'b', 'a', 'a', 'd']
list5 = list(set(list4))

for i in sorted(list5):
    print(i, '\t', list4.count(i))
