w = "word"
w_length = len(w)               # length of the word
index_end = w_length - 1        # length minus 1, i.e. index of the word’ last letter

w_new = []

i = index_end
while i >= 0:
    w_new.append(w[i])         # write the last letter into the w_new list
    i = i - 1                  # index of the word’s last letter but 1

print(''.join(w_new))
