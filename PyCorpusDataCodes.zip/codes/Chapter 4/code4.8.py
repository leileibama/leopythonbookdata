str1 = '''My father's family name being Pirrip, and my Christian name Philip, my infant tongue could make of both names nothing longer or more explicit than Pip. So, I called myself Pip, and came to be called Pip.'''

list1 = str1.split()
list2 = []

for word in list1:
    if len(word) >= 6:
        list2.append(word)

print(list2)
