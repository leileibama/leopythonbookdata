list3 = [1, 5, 8, 12]
print(sorted(list3, reverse = True))                           # [12, 8, 5, 1]

list4 = ['a', 'BB', 'Aa', 'ba', 'c', 'A', 'Cb', 'b', 'CC']
print(sorted(list4, key = str.lower, reverse = True))          # ['CC', 'Cb', 'c', 'BB', 'ba', 'b', 'Aa', 'a', 'A']
