list3 = ['a', 'c', 'b', 'b', 'a']
list4 = []

for i in list3:
    if i not in list4:
        list4.append(i)

print(list4)
