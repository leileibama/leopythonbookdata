list4 = ['a', 'BB', 'Aa', 'ba', 'c', 'A', 'Cb', 'b', 'CC']

print(sorted(list4, key = str.lower))    # ['a', 'A', 'Aa', 'b', 'ba', 'BB', 'c', 'Cb', 'CC']
