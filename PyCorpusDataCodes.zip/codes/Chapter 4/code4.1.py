list1 = range(1, 6)

for i in list1:
    print(i, '*', i, '=', i * i)
