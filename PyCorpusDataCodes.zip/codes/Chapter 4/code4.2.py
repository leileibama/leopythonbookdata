list1 = range(1, 6)

print(list1[0])       # 1
print(list1[-1])      # 5

for i in list1[0:2]:
    print(i)          # print 1 and 2
