tup3 = ('Mary', 'Tom', 'Julia', 'Michael')

if 'Julia' in tup3:
    print('Julia is in the tuple.')
