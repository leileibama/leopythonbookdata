list3 = ['a', 'c', 'b', 'b', 'a']

list3.pop()
print(list3)                       # ['a', 'c', 'b', 'b']

list3.pop()
print(list3)                       # ['a', 'c', 'b']
