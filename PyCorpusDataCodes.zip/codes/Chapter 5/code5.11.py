import re

string = '''A01  17 <p_>The bill was immediately sent to the House, which voted 308-114 
A01  18 for the override, 26 more than needed. A cheer went up as the House 
A01  19 vote was tallied, ending Bush's string of successful vetoes at 
A01  20 35.<p/>
A01  21 <p_>Among those voting to override in the Senate was Democratic 
A01  22 vice presidential nominee Al Gore, a co-author of the bill. He then 
A01  23 left the chamber to join Democratic presidential nominee Bill 
A01  24 Clinton on 'Larry King Live' on CNN.<p/>
'''

string1 = re.sub(r'A01\s+\d+\s', r'', string)

string2 = re.sub(r'\n', r'', string1)

string3 = re.sub(r'<p/>', r'<p/>\n', string2)

string4 = re.sub(r'<.*?>', r'', string3)

print(string4)
