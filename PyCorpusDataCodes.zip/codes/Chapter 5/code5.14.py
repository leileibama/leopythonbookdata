import re

file_in = open("../texts/ge_wordlist.txt", "r")
file_out = open("../ge_wordlist2.txt", "a")

#Use the followings for Python 3.x
#file_in = open("../texts/ge_wordlist.txt", "r", encoding = 'utf-8')
#file_out = open("../ge_wordlist2.txt", "a", encoding = 'utf-8')

wordlist = []

for line in file_in.readlines():
    line2 = re.sub(r'\W', ' ', line)    # Replace all non-alphanumeric characters with space
    list_of_words = line2.split()       # Split string based on space
    
    for word in list_of_words:
        wordlist.append(word)

wordlist1 = list(set(wordlist))         # Remove repetition in the list
wordlist2 = sorted(wordlist1)           # Sort list in alphabetic order

for w in wordlist2:
    file_out.write(w + '\n')

file_in.close()
file_out.close()
