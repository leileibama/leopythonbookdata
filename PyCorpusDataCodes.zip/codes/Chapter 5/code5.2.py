import re

string = 'His phone number is 12345678.'

print(re.findall(r'.', string))     # ['H', 'i', 's', ' ', 'p', 'h', 'o', 'n', 'e', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ', 'i', 's', ' ', '1', '2', '3', '4', '5', '6', '7', '8', '.']

print(re.findall(r'\w', string))    # ['H', 'i', 's', 'p', 'h', 'o', 'n', 'e', 'n', 'u', 'm', 'b', 'e', 'r', 'i', 's', '1', '2', '3', '4', '5', '6', '7', '8']

print(re.findall(r'\s', string))    # [' ', ' ', ' ', ' ']

print(re.findall(r'\d', string))    # ['1', '2', '3', '4', '5', '6', '7', '8']

print(re.findall(r'is', string))    # ['is', 'is']

print(re.findall(r'\bis', string))  # ['is']

print(re.findall(r'is\b', string))  # ['is', 'is']

print(re.findall(r'e', string))     # ['e', 'e']

print(re.findall(r'e\b', string))   # ['e']
