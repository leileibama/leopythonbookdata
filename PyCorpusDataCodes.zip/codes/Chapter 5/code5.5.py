import re

string = "<p_>The bill was immediately sent to the House, which voted 308-114 for the override, 26 more than needed. A cheer went up as the House vote was tallied, ending Bush's string of successful vetoes at 35.<p/>"

print(re.findall(r'.+', string))
print(re.findall(r'.*', string))
