import re

string = '''The homepage of our department is http://fld.hust.edu.cn/.
His email address is jason.lee@hotmail.com.

Name: Jason
Birthday: 08-12-1988
'''

print(re.findall(r'http://.*?/', string))            # ['http://fld.hust.edu.cn/']
print(re.findall(r'\w+\.\w+@\w+\.\w+', string))      # ['jason.lee@hotmail.com']
print(re.findall(r'\d{2}\-\d{2}\-\d{4}', string))    # ['08-12-1988']
