import re

string = '''
A01  17 <p_>The bill was immediately sent to the House, which voted 308-114 
A01  18 for the override, 26 more than needed. A cheer went up as the House 
A01  19 vote was tallied, ending Bush's string of successful vetoes at 
A01  20 35.<p/>
A01  21 <p_>Among those voting to override in the Senate was Democratic 
A01  22 vice presidential nominee Al Gore, a co-author of the bill. He then 
A01  23 left the chamber to join Democratic presidential nominee Bill 
A01  24 Clinton on 'Larry King Live' on CNN.<p/>
'''

print(re.findall(r'\w*ing\b', string))      # ['ending', 'string', 'voting', 'King']

print(re.findall(r'\bth\w+', string))       # ['the', 'the', 'than', 'the', 'those', 'the', 'the', 'then', 'the']

print(re.findall(r'\w*\d+\w*', string))     # ['A01', '17', '308', '114', 'A01', '18', '26', 'A01', '19', 'A01', '20', '35', 'A01', '21', 'A01', '22', 'A01', '23', 'A01', '24']

print(re.findall(r'\w+-\w+', string))       # ['308-114', 'co-author']

print(re.findall(r'\b\w\w\b', string))      # ['17', 'p_', 'to', '18', '26', 'up', 'as', '19', 'of', 'at', '20', '35', '21', 'p_', 'to', 'in', '22', 'Al', 'co', 'of', 'He', '23', 'to', '24', 'on', 'on']

print(re.findall(r'A\d+\s+\d+\s', string))  # ['A01  17 ', 'A01  18 ', 'A01  19 ', 'A01  20 ', 'A01  21 ', 'A01  22 ', 'A01  23 ', 'A01  24 ']
