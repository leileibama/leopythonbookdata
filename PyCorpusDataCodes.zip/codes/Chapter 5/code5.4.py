import re

string = '''
Mary  Michael  Susan  Larry  Christina
Elizabeth   Juliana   Julia   Leo  Jane
Jason  Johansson  John   Bill  Katherine
'''

print(re.findall(r'\b\w{3,4}\b', string))         # ['Mary', 'Leo', 'Jane', 'John', 'Bill']

print(re.findall(r'\b\w{6,}\b', string))          # ['Michael', 'Christina', 'Elizabeth', 'Juliana', 'Johansson', 'Katherine']

print(re.findall(r'\bJ\w*a\b', string))           # ['Juliana', 'Julia']

print(re.findall(r'\bJ\w{5,}a\b', string))        # ['Juliana']

print(re.findall(r'\b[JKLM]\w{4,}\b', string))    # ['Michael', 'Larry', 'Juliana', 'Julia', 'Jason', 'Johansson', 'Katherine']
