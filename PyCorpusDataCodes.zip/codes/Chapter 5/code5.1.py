import re
string = 'abcdbcdcd'

# Note: usually the letter 'r' goes before a string, meaning its a 'raw string'
print(re.findall(r'abc', string))               # ['abc']
print(re.findall(r'bc', string))                # ['bc', 'bc']
print(re.findall(r'cdd', string))               # []
