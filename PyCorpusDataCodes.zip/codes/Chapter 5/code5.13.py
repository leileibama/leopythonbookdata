import re

string = '''<p><s n="1"><w type="NP" subtype="HL">Elburn</w> <c type="pct">,</c> <w type="NP" subtype="HL">Ill.</w> </s>
<s n="2"><c type="pct">--</c> <w type="NN">Farm</w> <w type="NN">machinery</w> <w type="NN">dealer</w> <w type="NP">Bob</w> <w type="NP">Houtz</w> <w type="VBZ">tilts</w> <w type="RB">back</w> <w type="IN">in</w> <w type="AT">a</w> <w type="VBN">battered</w> <w type="NN">chair</w> <w type="CC">and</w> <w type="VBZ">tells</w> <w type="IN">of</w> <w type="AT">a</w> <w type="JJ">sharp</w> <w type="NN">pickup</w> <w type="IN">in</w> <w type="NNS">sales</w> <c type="pct">:</c> <c type="pct">``</c> <mw pos="PPSS HV">We've </mw><w type="VBN">sold</w> <w type="CD">four</w> <w type="NN">corn</w> <w type="NNS">pickers</w> <w type="IN">since</w> <w type="NN" subtype="TL">Labor</w> <w type="NN" subtype="TL">Day</w> <w type="CC">and</w> <w type="HV">have</w> <w type="JJ">good</w> <w type="NNS">prospects</w> <w type="IN">for</w> <w type="CD">10</w> <w type="AP">more</w> <c type="pct">.</c> </s>
<s n="3"><w type="PPSS">We</w> <w type="VBD">sold</w> <w type="RB">only</w> <w type="CD">four</w> <w type="NNS">pickers</w> <w type="ABN">all</w> <w type="AP">last</w> <w type="NN">year</w> <c type="pct">''</c> <c type="pct">.</c> </s>
</p>
<p><s n="4"><w type="NP">Gus</w> <w type="NP">Ehlers</w> <c type="pct">,</c> <w type="NN">competitor</w> <w type="IN">of</w> <w type="NP">Mr.</w> <w type="NP">Houtz</w> <w type="IN">in</w> <w type="DT">this</w> <w type="NN">farm</w> <w type="NN">community</w> <c type="pct">,</c> <w type="VBZ">says</w> <w type="PPg">his</w> <w type="NN">business</w> <w type="IN">since</w> <w type="NP">August</w> <w type="CD">1</w> <w type="BEZ">is</w> <w type="VBG">running</w> <w type="NN">50%</w> <w type="IN">above</w> <w type="AT">a</w> <w type="NN">year</w> <w type="RBR">earlier</w> <c type="pct">.</c> </s>
<s n="5"><c type="pct">``</c> <w type="IN">Before</w> <w type="RB">then</w> <c type="pct">,</c> <w type="PPg">my</w> <w type="NNS">sales</w> <w type="IN">during</w> <w type="AP">much</w> <w type="IN">of</w> <w type="AT">the</w> <w type="NN">year</w> <w type="HVD">had</w> <w type="VBN">lagged</w> <w type="IN">behind</w> <w type="CD">1960</w> <w type="IN">by</w> <w type="NN">20%</w> <c type="pct">''</c> <c type="pct">,</c> <w type="PPS">he</w> <w type="VBZ">says</w> <c type="pct">.</c> </s>
</p>
'''

string1 = re.sub(r'<[wscm].*?>', r'', string)

string2 = re.sub(r'</[wcsm]\w*>', r'', string1)

string3 = re.sub(r'\n', r'', string2)

string4 = re.sub(r'</p>', r'</p>\n', string3)

string5 = re.sub(r'<.*?>', r'', string4)

print(string5)
