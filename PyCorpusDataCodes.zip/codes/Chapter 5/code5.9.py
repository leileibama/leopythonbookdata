import re

string = '''The/at marriage/nn of/in John/np and/cc Mary/np Black/np had/hvd clearly/rb reached/vbn the/at breaking/vbg point/nn after/in eight/cd years/nns ./.
'''

print(re.findall(r'\w+/np', string))                # ['John/np', 'Mary/np', 'Black/np']

print(re.findall(r'\w+/n\w+', string))              # ['marriage/nn', 'John/np', 'Mary/np', 'Black/np', 'point/nn', 'years/nns']

print(re.findall(r'\w+/v\w+', string))              # ['reached/vbn', 'breaking/vbg']

print(re.findall(r'\w+/at.*?\w+/nn\w*', string))    # ['The/at marriage/nn', 'the/at breaking/vbg point/nn']

print(re.findall(r'\w+/rb.*?\w+/v\w*', string))     # ['clearly/rb reached/vbn']

print(re.findall(r'/\w+|/\.', string))              # ['/at', '/nn', '/in', '/np', '/cc', '/np', '/np', '/hvd', '/rb', '/vbn', '/at', '/vbg', '/nn', '/in', '/cd', '/nns', '/.']

# '|' represents 'or'. The above expression can also be written as '(/\w+)|(/\.)'
