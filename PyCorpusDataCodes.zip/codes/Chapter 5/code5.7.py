import re

web = r'The website of HUST is http://www.hust.edu.cn.'

matched1 = re.findall(r'(http)://(www).(\w+).(\w+).(\w+)', web)
print(matched1)             # [('http', 'www', 'hust', 'edu', 'cn')]
print(matched1[0][0])       # http
print(matched1[0][1])       # www

matched2 = re.search(r'(http)://(www).(\w+).(\w+).(\w+)', web)
print(matched2.group(0))    # http://www.hust.edu.cn
print(matched2.group(1))    # http
print(matched2.group(2))    # www
print(matched2.group(3))    # hust
print(matched2.group(4))    # edu
print(matched2.group(5))    # cn
