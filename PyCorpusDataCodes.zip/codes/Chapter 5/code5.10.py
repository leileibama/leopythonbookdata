import re

string = '''Elburn ,        Ill.


-- Farm machinery       dealer Bob Houtz    tilts back in a battered chair and tells of a sharp pickup in sales : `` We've sold four   corn pickers    since Labor       Day and        have good       prospects for 10 more . We sold only four pickers all last year '' .




Gus Ehlers , competitor       of Mr. Houtz in this farm community , says        his business   since August 1 is     running 50% above a year earlier . `` Before then , my sales during much            of the year had lagged behind 1960 by 20% '' , he says .
'''

string1 = re.sub(r' {2,}', r' ', string)

string2 = re.sub(r'\s{2,}', r'\n', string1)

print(string2)
